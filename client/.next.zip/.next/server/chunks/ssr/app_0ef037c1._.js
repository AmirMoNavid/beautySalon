module.exports=[53787,a=>{a.v("/_next/static/media/favicon.f76c8d3d.ico")},47290,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(53787).default,width:1280,height:1280}}];

//# sourceMappingURL=app_0ef037c1._.js.map