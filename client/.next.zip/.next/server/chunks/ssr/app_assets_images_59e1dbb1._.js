module.exports=[7387,a=>{a.v("/_next/static/media/telegram.664acb3d.png")},14673,a=>{a.v("/_next/static/media/twitter.5579a023.png")},91579,a=>{a.v("/_next/static/media/whatsapp.d6bee695.png")}];

//# sourceMappingURL=app_assets_images_59e1dbb1._.js.map