globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/1d5f272408304653.js",
      "static/chunks/turbopack-e52856251f0d9749.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/1d5f272408304653.js",
      "static/chunks/turbopack-0be3963da2e04f7e.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c78379bcaeb456f7.js",
    "static/chunks/865559f793beefde.js",
    "static/chunks/e159d877b17ca256.js",
    "static/chunks/4cc883a7143a9f48.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-0b356e9870b20b76.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];