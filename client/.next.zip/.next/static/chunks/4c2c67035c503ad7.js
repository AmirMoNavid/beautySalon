__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/1d5f272408304653.js",
  "static/chunks/turbopack-e52856251f0d9749.js"
])
